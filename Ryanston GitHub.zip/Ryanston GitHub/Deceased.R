#Reading the Dataset
dataset=read.csv('Covid_Project.csv')
View(dataset)

#Splitting of Data Set into Test Set and Training Set
library('caTools')
set.seed(123)
split=sample.split(dataset$Deceased,SplitRatio = 0.8)
training_set=subset(dataset,split==TRUE)
test_set=subset(dataset,split==FALSE)

#Fitting the Linear Regressor
regressor=lm(formula=Deceased~Day,data=training_set)
summary(regressor)

#Predicting the Estimated Value
y_pred=predict(regressor,newdata = test_set)

#Plotting of Graph
library(ggplot2)
ggplot()+
  geom_point(aes(x=training_set$Day,y=training_set$Deceased),
             colour='red')+
  geom_line(aes(x=training_set$Day,y=predict(regressor,newdata = training_set)),
            colour='blue')+
  ggtitle('Covid_19')+
  xlab('Days')+
  ylab('Deceased')

#Calculating the Required Estimate
-13.6945+2.4652*48