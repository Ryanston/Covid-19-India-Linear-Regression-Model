#Reading the Dataset
dataset=read.csv('Covid_Project.csv')
View(dataset)

#Splitting of Data Set into Test Set and Training Set
library('caTools')
set.seed(123)
split=sample.split(dataset$Recovered,SplitRatio = 0.8)
training_set=subset(dataset,split==TRUE)
test_set=subset(dataset,split==FALSE)

#Fitting the Linear Regressor
regressor=lm(formula=Recovered~Day,data=training_set)
summary(regressor)

#Predicting the Estimated Value
y_pred=predict(regressor,newdata = test_set)

#Plotting of Graph
library(ggplot2)
ggplot()+
  geom_point(aes(x=training_set$Day,y=training_set$Recovered),
             colour='red')+
  geom_line(aes(x=training_set$Day,y=predict(regressor,newdata = training_set)),
            colour='blue')+
  ggtitle('Covid_19')+
  xlab('Days')+
  ylab('Recovered')

#Calculating the Required Estimate
